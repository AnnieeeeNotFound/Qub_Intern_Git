/**
 * Memristor-Discovery is distributed under the GNU General Public License version 3 and is also
 * available under alternative licenses negotiated directly with Knowm, Inc.
 *
 * <p>Copyright (c) 2016-2020 Knowm Inc. www.knowm.org
 *
 * <p>This package also includes various components that are not part of Memristor-Discovery itself:
 *
 * <p>* `Multibit`: Copyright 2011 multibit.org, MIT License * `SteelCheckBox`: Copyright 2012
 * Gerrit, BSD license
 *
 * <p>Knowm, Inc. holds copyright and/or sufficient licenses to all components of the
 * Memristor-Discovery package, and therefore can grant, at its sole discretion, the ability for
 * companies, individuals, or organizations to create proprietary or open source (even if not GPL)
 * modules which may be dynamically linked at runtime with the portions of Memristor-Discovery which
 * fall under our copyright/license umbrella, or are distributed under more flexible licenses than
 * GPL.
 *
 * <p>The 'Knowm' name and logos are trademarks owned by Knowm, Inc.
 *
 * <p>If you have any questions regarding our licensing policy, please contact us at
 * `contact@knowm.org`.
 */
package org.knowm.memristor.discovery.gui;

import java.awt.BorderLayout;
import java.awt.Dimension;
import java.text.SimpleDateFormat;
import java.util.Date;
import javax.swing.JDialog;
import javax.swing.JScrollPane;
import javax.swing.JTextArea;
import javax.swing.SwingUtilities;

public class ConsoleDialog extends JDialog {

  private final JTextArea textArea;
  private SimpleDateFormat dateFormat = new SimpleDateFormat("HH-mm-ss");

  /** Constructor */
  public ConsoleDialog() {

    super(null, ModalityType.MODELESS);

    setPreferredSize(new Dimension(1000, 500));
    setTitle("Console");
    getContentPane().setLayout(new BorderLayout());

    textArea = new JTextArea(15, 30);
    add(
        new JScrollPane(
            textArea,
            JScrollPane.VERTICAL_SCROLLBAR_ALWAYS,
            JScrollPane.HORIZONTAL_SCROLLBAR_NEVER),
        BorderLayout.CENTER);

    pack();
    setDefaultCloseOperation(JDialog.DISPOSE_ON_CLOSE);
  }

  public void addConsoleMessage(String text) {

    // System.out.println("addConsoleMessage(" + text + ")");

    SwingUtilities.invokeLater(
        new Runnable() {

          @Override
          public void run() {

            textArea.append(dateFormat.format(new Date()) + " : " + text + "\n");
          }
        });
  }
}
