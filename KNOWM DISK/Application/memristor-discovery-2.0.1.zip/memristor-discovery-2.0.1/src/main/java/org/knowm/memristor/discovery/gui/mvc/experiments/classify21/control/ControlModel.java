/**
 * Memristor-Discovery is distributed under the GNU General Public License version 3 and is also
 * available under alternative licenses negotiated directly with Knowm, Inc.
 *
 * <p>Copyright (c) 2016-2020 Knowm Inc. www.knowm.org
 *
 * <p>This package also includes various components that are not part of Memristor-Discovery itself:
 *
 * <p>* `Multibit`: Copyright 2011 multibit.org, MIT License * `SteelCheckBox`: Copyright 2012
 * Gerrit, BSD license
 *
 * <p>Knowm, Inc. holds copyright and/or sufficient licenses to all components of the
 * Memristor-Discovery package, and therefore can grant, at its sole discretion, the ability for
 * companies, individuals, or organizations to create proprietary or open source (even if not GPL)
 * modules which may be dynamically linked at runtime with the portions of Memristor-Discovery which
 * fall under our copyright/license umbrella, or are distributed under more flexible licenses than
 * GPL.
 *
 * <p>The 'Knowm' name and logos are trademarks owned by Knowm, Inc.
 *
 * <p>If you have any questions regarding our licensing policy, please contact us at
 * `contact@knowm.org`.
 */
package org.knowm.memristor.discovery.gui.mvc.experiments.classify21.control;

import java.text.DecimalFormat;
import org.knowm.memristor.discovery.core.driver.Driver;
import org.knowm.memristor.discovery.core.driver.waveform.HalfSine;
import org.knowm.memristor.discovery.core.driver.waveform.QuarterSine;
import org.knowm.memristor.discovery.core.driver.waveform.Sawtooth;
import org.knowm.memristor.discovery.core.driver.waveform.Square;
import org.knowm.memristor.discovery.core.driver.waveform.SquareSmooth;
import org.knowm.memristor.discovery.core.driver.waveform.Triangle;
import org.knowm.memristor.discovery.gui.mvc.experiments.ExperimentPreferences;
import org.knowm.memristor.discovery.gui.mvc.experiments.Model;
import org.knowm.memristor.discovery.gui.mvc.experiments.classify21.Classify21Preferences;
import org.knowm.memristor.discovery.gui.mvc.experiments.classify21.Classify21Preferences.AHaHRoutine;
import org.knowm.memristor.discovery.gui.mvc.experiments.classify21.Classify21Preferences.Datasets;
import org.knowm.memristor.discovery.gui.mvc.experiments.synapse12.Synapse12Preferences;

public class ControlModel extends Model {

  /** Events */
  public static final String EVENT_INSTRUCTION_UPDATE = "EVENT_INSTRUCTION_UPDATE";

  private final double[] waveformTimeData = new double[Classify21Preferences.CAPTURE_BUFFER_SIZE];
  private final double[] waveformAmplitudeData =
      new double[Classify21Preferences.CAPTURE_BUFFER_SIZE];
  /** Waveform */
  public Classify21Preferences.Waveform waveform;

  private int pulseNumber = 1;
  public DecimalFormat ohmFormatter = new DecimalFormat("#,### Ω");
  public Classify21Preferences.Datasets dataset = Datasets.Ortho4Pattern;
  public AHaHRoutine ahahroutine = AHaHRoutine.LearnAlways;
  private float amplitude;
  private int pulseWidth; // model store pulse width in nanoseconds
  private int numTrainEpochs;

  private double scopeOneOffset;
  private double scopeTwoOffset;
  private double wOneOffset;

  /** Constructor */
  public ControlModel() {

    // updateWaveformChartData();
  }

  @Override
  public void doLoadModelFromPrefs(ExperimentPreferences experimentPreferences) {

    waveform =
        Classify21Preferences.Waveform.valueOf(
            experimentPreferences.getString(
                Classify21Preferences.WAVEFORM_INIT_STRING_KEY,
                Classify21Preferences.WAVEFORM_INIT_STRING_DEFAULT_VALUE));

    //    System.out.println("waveform = " + waveform);

    seriesResistance =
        experimentPreferences.getInteger(
            Classify21Preferences.SERIES_R_INIT_KEY,
            Classify21Preferences.SERIES_R_INIT_DEFAULT_VALUE);
    amplitude =
        experimentPreferences.getFloat(
            Classify21Preferences.AMPLITUDE_INIT_FLOAT_KEY,
            Classify21Preferences.AMPLITUDE_INIT_FLOAT_DEFAULT_VALUE);
    pulseWidth =
        experimentPreferences.getInteger(
            Classify21Preferences.PULSE_WIDTH_INIT_KEY,
            Classify21Preferences.PULSE_WIDTH_INIT_DEFAULT_VALUE);

    numTrainEpochs =
        experimentPreferences.getInteger(
            Classify21Preferences.NUM_TRAIN_EPOCHS_INIT_KEY,
            Classify21Preferences.NUM_TRAIN_EPOCHS_INIT_DEFAULT_VALUE);

    scopeOneOffset =
        experimentPreferences.getFloat(
            Synapse12Preferences.SCOPE_ONE_OFFSET_KEY,
            Synapse12Preferences.SCOPE_ONE_OFFSET_DEFAULT_VALUE);
    scopeTwoOffset =
        experimentPreferences.getFloat(
            Synapse12Preferences.SCOPE_TWO_OFFSET_KEY,
            Synapse12Preferences.SCOPE_TWO_OFFSET_DEFAULT_VALUE);
    wOneOffset =
        experimentPreferences.getFloat(
            Synapse12Preferences.W_ONE_OFFSET_KEY, Synapse12Preferences.W_ONE_OFFSET_DEFAULT_VALUE);
  }

  /** Given the state of the model, update the waveform x and y axis data arrays. */
  void updateWaveformChartData() {

    Driver driver;
    switch (waveform) {
      case Sawtooth:
        driver =
            new Sawtooth("Sawtooth", amplitude / 2, 0, amplitude / 2, getCalculatedFrequency());
        break;
      case QuarterSine:
        driver = new QuarterSine("QuarterSine", 0, 0, amplitude, getCalculatedFrequency());
        break;
      case Triangle:
        driver = new Triangle("Triangle", 0, 0, amplitude, getCalculatedFrequency());
        break;
      case Square:
        driver = new Square("Square", amplitude / 2, 0, amplitude / 2, getCalculatedFrequency());
        break;
      case SquareSmooth:
        driver = new SquareSmooth("SquareSmooth", 0, 0, amplitude, getCalculatedFrequency());
        break;
      default:
        driver = new HalfSine("HalfSine", 0, 0, amplitude, getCalculatedFrequency());
        break;
    }

    double stopTime = 1 / getCalculatedFrequency() * pulseNumber;
    double timeStep =
        1 / getCalculatedFrequency() / Classify21Preferences.CAPTURE_BUFFER_SIZE * pulseNumber;

    int counter = 0;
    for (double i = 0.0; i < stopTime; i = i + timeStep) {
      if (counter >= Classify21Preferences.CAPTURE_BUFFER_SIZE) {
        break;
      }
      waveformTimeData[counter] = i * Classify21Preferences.TIME_UNIT.getDivisor();
      waveformAmplitudeData[counter++] = driver.getSignal(i);
    }
  }

  // ///////////////////////////////////////////////////////////
  // GETTERS AND SETTERS //////////////////////////////////////
  // ///////////////////////////////////////////////////////////

  public float getAmplitude() {

    return amplitude;
  }

  public void setAmplitude(float amplitude) {

    this.amplitude = amplitude;
    swingPropertyChangeSupport.firePropertyChange(Model.EVENT_WAVEFORM_UPDATE, true, false);
  }

  public int getPulseWidth() {

    return pulseWidth;
  }

  public void setPulseWidth(int pulseWidth) {

    this.pulseWidth = pulseWidth;
    swingPropertyChangeSupport.firePropertyChange(Model.EVENT_WAVEFORM_UPDATE, true, false);
  }

  public double getCalculatedFrequency() {

    // System.out.println("pulseWidth = " + pulseWidth);
    return (1.0 / (2.0 * pulseWidth) * 1_000_000_000); // 50% duty cycle
  }

  public double[] getWaveformTimeData() {

    return waveformTimeData;
  }

  public double[] getWaveformAmplitudeData() {

    return waveformAmplitudeData;
  }

  //  public int getPulseNumber() {
  //
  //    return pulseNumber;
  //  }
  //
  //  public void setPulseNumber(int pulseNumber) {
  //
  //    this.pulseNumber = pulseNumber;
  //    swingPropertyChangeSupport.firePropertyChange(Model.EVENT_WAVEFORM_UPDATE,
  // true, false);
  //  }

  public Classify21Preferences.Waveform getWaveform() {

    return waveform;
  }

  public void setWaveform(Classify21Preferences.Waveform waveform) {

    this.waveform = waveform;
    swingPropertyChangeSupport.firePropertyChange(Model.EVENT_WAVEFORM_UPDATE, true, false);
  }

  public void setWaveform(String text) {

    this.waveform = Enum.valueOf(Classify21Preferences.Waveform.class, text);
    swingPropertyChangeSupport.firePropertyChange(Model.EVENT_WAVEFORM_UPDATE, true, false);
  }

  public int getNumTrainEpochs() {

    return numTrainEpochs;
  }

  public void setNumTrainEpochs(int epochs) {

    this.numTrainEpochs = epochs;
  }

  public Classify21Preferences.Datasets getDataset() {

    return dataset;
  }

  public void setDataStructure(String text) {

    this.dataset = Enum.valueOf(Classify21Preferences.Datasets.class, text);
  }

  public AHaHRoutine getAhahroutine() {
    return ahahroutine;
  }

  public double getScopeOneOffset() {
    return scopeOneOffset;
  }

  public double getScopeTwoOffset() {
    return scopeTwoOffset;
  }

  public double getwOneOffset() {
    return wOneOffset;
  }
}
